/* Glass headline for the hero: a plain-JavaScript port of the "Glass Headline Hero"
   WebGL2 component (originally React). The headline stays real text; this script
   paints refractive glass exactly over each word. Outside the letters the canvas adds a soft
   animated glow (strongest on the left) over the hero's background image.
   Without WebGL2 (or if anything fails) the normal solid headline is shown. */
(function () {
  "use strict";

  // Palette taken from the site: dark ground, logo blue, teal, deep blue, pale ice.
  var COLORS = ["#06101F", "#2D8CE8", "#35D1C4", "#1E4FD8", "#DDF1FF"];
  var FORM_MS = 1100, DOME = 3, IDLE_S = 2.5, SLOW_FRAME_S = 0.05, SLOW_FRAMES = 8, CRAWL_FRAME_S = 0.15;

  var hero = document.querySelector(".hero");
  var canvas = hero && hero.querySelector(".glass-canvas");
  var heading = hero && hero.querySelector("h1");
  if (!hero || !canvas || !heading) return;

  /* ---- helpers ---- */
  function hexToRgb(hex) {
    var v = parseInt(hex.replace("#", ""), 16);
    return [((v >> 16) & 255) / 255, ((v >> 8) & 255) / 255, (v & 255) / 255];
  }
  var palette = COLORS.map(hexToRgb);
  var bevelPx = function (fontPx, scale) { return Math.max(2, fontPx * 0.075 * scale); };
  var formed = function (t, ms) { var x = Math.min(Math.max(t / ms, 0), 1); return 1 - Math.pow(1 - x, 3); };
  var follow = function (from, to, dt, rate) { return to + (from - to) * Math.exp(-rate * dt); };
  var orbit = function (t) { return [0.5 + 0.32 * Math.sin(t * 0.37), 0.56 + 0.16 * Math.sin(t * 0.53 + 1.1)]; };

  /* ---- split every headline line into word spans (text stays real text) ---- */
  Array.prototype.forEach.call(heading.children, function (line) {
    var words = line.textContent.trim().split(/\s+/);
    line.innerHTML = words.map(function (w) { return '<span class="ghr-word">' + w + "</span>"; }).join(" ");
  });

  /* ---- shaders ---- */
  var VERT = "#version 300 es\nin vec2 a_position;\nout vec2 vUv;\nvoid main(){vUv=a_position*0.5+0.5;gl_Position=vec4(a_position,0.0,1.0);}";
  var HEAD = "#version 300 es\nprecision highp float;\nin vec2 vUv;\nout vec4 o;\n";

  // Flowing colour field that bends behind the letters.
  var FIELD = HEAD + "uniform float u_time;uniform float u_aspect;uniform vec3 u_c0;uniform vec3 u_c1;uniform vec3 u_c2;uniform vec3 u_c3;uniform vec3 u_c4;uniform float u_octaves;" +
    "float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}" +
    "float noise(vec2 p){vec2 i=floor(p);vec2 f=fract(p);vec2 u=f*f*(3.0-2.0*f);return mix(mix(hash(i),hash(i+vec2(1.0,0.0)),u.x),mix(hash(i+vec2(0.0,1.0)),hash(i+vec2(1.0,1.0)),u.x),u.y);}" +
    "float fbm(vec2 p){float v=0.0;float a=0.5;mat2 turn=mat2(0.8,0.6,-0.6,0.8);for(int i=0;i<5;i++){if(float(i)>=u_octaves)break;v+=a*noise(p);p=turn*p*2.02;a*=0.5;}return v;}" +
    "void main(){vec2 p=vec2(vUv.x*u_aspect,vUv.y)*1.2;float t=u_time*0.06;" +
    "vec2 q=vec2(fbm(p+vec2(0.0,t)),fbm(p+vec2(5.2,1.3)-t));" +
    "vec2 r=vec2(fbm(p+3.5*q+vec2(1.7,9.2)+t*1.4),fbm(p+3.5*q+vec2(8.3,2.8)-t*1.1));" +
    "float f=fbm(p+3.0*r);vec3 col=u_c0;" +
    "col=mix(col,u_c3,smoothstep(0.25,0.72,q.x)*0.9);col=mix(col,u_c1,smoothstep(0.34,0.74,f));" +
    "col=mix(col,u_c2,smoothstep(0.42,0.8,r.y)*0.8);col=mix(col,u_c4,smoothstep(0.55,0.9,f*r.x*1.8)*0.7);" +
    "float bands=0.5+0.5*sin((f*7.0+r.x*3.0)*3.14159);col*=mix(0.86,1.1,smoothstep(0.2,0.8,bands));" +
    "vec2 g=(vUv-vec2(0.5,0.56))/vec2(0.5,0.2);col+=u_c4*0.07*exp(-dot(g,g));" +
    "col*=mix(0.85,1.0,smoothstep(0.02,0.5,vUv.y));o=vec4(col,1.0);}";

  // Separable gaussian over the headline mask: R = bevel, B = dome, G = sharp mask.
  var BLUR = HEAD + "uniform sampler2D u_src;uniform vec2 u_step;uniform float u_radius;uniform float u_read;uniform float u_write;" +
    "float pick(vec4 t){return u_read<0.5?smoothstep(0.06,1.0,t.r):u_read<1.5?t.r:t.b;}" +
    "void main(){float sigma=max(u_radius*0.5,0.5);float sum=0.0;float weights=0.0;" +
    "for(int i=-24;i<=24;i++){float x=float(i)*u_radius/24.0;float w=exp(-0.5*x*x/(sigma*sigma));sum+=pick(texture(u_src,vUv+u_step*x))*w;weights+=w;}" +
    "vec4 here=texture(u_src,vUv);float blurred=sum/weights;" +
    "o=vec4(u_write<0.5?blurred:here.r,here.g,u_write<0.5?here.b:blurred,1.0);}";

  // The glass itself. Output is premultiplied RGBA: opaque inside letters, a soft
  // shadow just outside them, fully transparent elsewhere.
  var GLASS = HEAD + "uniform sampler2D u_field;uniform sampler2D u_height;uniform vec2 u_htexel;uniform float u_bevel;uniform float u_aspect;uniform vec2 u_light;uniform float u_glass;uniform float u_form;uniform vec2 u_res;" +
    "float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}" +
    "float bevel(vec2 p){vec4 t=texture(u_height,p);float x=clamp((t.r-0.5)*2.0,0.0,1.0);float edge=sqrt(1.0-(1.0-x)*(1.0-x));float dome=clamp((t.b-0.5)*2.0,0.0,1.0);return edge*0.8+dome*0.45;}" +
    "void main(){vec2 uv=vUv;vec2 hv=texture(u_height,uv).rg;float inside=smoothstep(0.08,0.92,hv.g)*u_glass*u_form;" +
    "vec2 dx=vec2(u_htexel.x*2.0,0.0);vec2 dy=vec2(0.0,u_htexel.y*2.0);" +
    "float tl=bevel(uv-dx+dy);float tc=bevel(uv+dy);float tr=bevel(uv+dx+dy);float ml=bevel(uv-dx);float mr=bevel(uv+dx);float bl=bevel(uv-dx-dy);float bc=bevel(uv-dy);float br=bevel(uv+dx-dy);" +
    "vec2 grad=vec2((tr+2.0*mr+br)-(tl+2.0*ml+bl),(tl+2.0*tc+tr)-(bl+2.0*bc+br))/16.0*u_bevel;vec3 n=normalize(vec3(-grad*0.9,1.0));" +
    "vec2 toLight=(u_light-uv)*vec2(u_aspect,1.0);vec3 L=normalize(vec3(toLight,0.45));vec3 halfway=normalize(L+vec3(0.0,0.0,1.0));" +
    "float facing=max(dot(n,halfway),0.0);float pin=pow(facing,160.0);float sheen=pow(facing,24.0);float rim=pow(1.0-n.z,2.0);float studio=smoothstep(-0.7,0.7,n.y);" +
    "vec2 bend=-n.xy*0.05*u_form*vec2(1.0/u_aspect,1.0);" +
    "vec3 through=vec3(texture(u_field,uv+bend*0.84).r,texture(u_field,uv+bend).g,texture(u_field,uv+bend*1.18).b);" +
    "vec2 ld=normalize(toLight+1e-5);float gather=rim*max(dot(normalize(n.xy+1e-5),-ld),0.0);" +
    "vec3 glass=through*0.86+0.06+rim*mix(0.28,0.72,studio)+sheen*0.16+pin*1.3+gather*vec3(1.0,0.93,0.82)*0.55;" +
    "float lip=smoothstep(0.42,0.5,hv.r)*(1.0-smoothstep(0.5,0.6,hv.r));glass*=1.0-0.28*lip;" +
    "vec2 away=normalize(toLight+1e-5)*vec2(1.0/u_aspect,1.0);float shade=texture(u_height,uv+away*0.012).r;" +
    "float shadow=0.4*smoothstep(0.1,0.7,shade)*u_glass;" +
    "glass+=(hash(floor(uv*u_res))-0.5)*0.018;" +
    "vec3 wash=texture(u_field,uv).rgb*0.27*mix(1.0,0.2,smoothstep(0.25,0.9,uv.x))*(1.0-shadow);" +
    "float a=inside+(1.0-inside)*shadow;o=vec4(glass*inside+wash*(1.0-inside),a);}";

  /* ---- engine ---- */
  function start() {
    var gl = canvas.getContext("webgl2", { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false });
    if (!gl) return function () {};
    var floatTargets = !!gl.getExtension("EXT_color_buffer_float");
    var reduceMq = window.matchMedia("(prefers-reduced-motion: reduce)");
    var disposed = false, raf = 0, last = 0, time = 0, inView = true, lite = false, judged = 0, slow = 0, readyAt = -1, built = "";
    var light = { x: 0.5, y: 0.56 };
    var pt = { x: 0.5, y: 0.56, at: -1e9 };
    var owned = { tex: [], fbo: [] };
    var P, field = null, blurA = null, blurB = null, maskTex = null, bevel = 4;

    function shader(type, src) {
      var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s));
      return s;
    }
    function program(frag) {
      var prog = gl.createProgram(), v = shader(gl.VERTEX_SHADER, VERT), f = shader(gl.FRAGMENT_SHADER, frag);
      gl.attachShader(prog, v); gl.attachShader(prog, f); gl.bindAttribLocation(prog, 0, "a_position"); gl.linkProgram(prog);
      gl.deleteShader(v); gl.deleteShader(f);
      if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(prog));
      var u = {}, n = gl.getProgramParameter(prog, gl.ACTIVE_UNIFORMS);
      for (var i = 0; i < n; i++) { var info = gl.getActiveUniform(prog, i); if (info) u[info.name.replace(/^u_/, "")] = gl.getUniformLocation(prog, info.name); }
      return { prog: prog, u: u };
    }
    function makeTarget(w, h, precise) {
      var tex = gl.createTexture(), fbo = gl.createFramebuffer();
      gl.bindTexture(gl.TEXTURE_2D, tex);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      if (precise && floatTargets) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, w, h, 0, gl.RGBA, gl.HALF_FLOAT, null);
      else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
      owned.tex.push(tex); owned.fbo.push(fbo);
      return { tex: tex, fbo: fbo, w: w, h: h };
    }
    function run(p, dst, u) {
      gl.useProgram(p.prog);
      var unit = 0;
      for (var k in u) {
        var loc = p.u[k]; if (!loc) continue;
        var v = u[k];
        if (typeof v === "number") gl.uniform1f(loc, v);
        else if (Array.isArray(v)) { if (v.length === 2) gl.uniform2f(loc, v[0], v[1]); else gl.uniform3f(loc, v[0], v[1], v[2]); }
        else { gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, v); gl.uniform1i(loc, unit++); }
      }
      gl.bindFramebuffer(gl.FRAMEBUFFER, dst ? dst.fbo : null);
      gl.viewport(0, 0, dst ? dst.w : canvas.width, dst ? dst.h : canvas.height);
      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }

    // Draw each word in white on black where the browser placed it, blur into a height field.
    function buildMask() {
      if (!field) return;
      var box = hero.getBoundingClientRect();
      var scale = lite ? 1 : Math.min(window.devicePixelRatio || 1, 1.5);
      var w = Math.max(1, Math.round(box.width * scale)), h = Math.max(1, Math.round(box.height * scale));
      var spans = Array.prototype.slice.call(heading.querySelectorAll(".ghr-word"));
      var rects = spans.map(function (s) { return s.getBoundingClientRect(); });
      var hcs = getComputedStyle(heading);
      var key = [w, h, scale, hcs.fontFamily].concat(spans.map(function (s, i) {
        return s.textContent + "@" + Math.round(rects[i].left - box.left) + "," + Math.round(rects[i].top - box.top) + "," + getComputedStyle(s).fontSize;
      })).join("|");
      if (key === built) return;
      built = key;
      var cnv = document.createElement("canvas"); cnv.width = w; cnv.height = h;
      var c = cnv.getContext("2d"); if (!c) return;
      c.fillStyle = "#000"; c.fillRect(0, 0, w, h);
      c.setTransform(scale, 0, 0, scale, 0, 0);
      c.fillStyle = "#fff"; c.textBaseline = "alphabetic";
      var fontPx = parseFloat(hcs.fontSize) || 64;
      spans.forEach(function (span, i) {
        var cs = getComputedStyle(span);
        c.font = cs.fontStyle + " " + cs.fontWeight + " " + cs.fontSize + " " + cs.fontFamily;
        if ("letterSpacing" in c) c.letterSpacing = cs.letterSpacing === "normal" ? "0px" : cs.letterSpacing;
        var text = span.textContent;
        var ascent = c.measureText(text).fontBoundingBoxAscent || (parseFloat(cs.fontSize) || fontPx) * 0.8;
        c.fillText(text, rects[i].left - box.left, rects[i].top - box.top + ascent);
      });
      if (!maskTex) maskTex = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, maskTex);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, cnv);
      gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      if (!blurA || blurA.w !== w || blurA.h !== h) {
        [blurA, blurB].forEach(function (t) { if (t) { gl.deleteTexture(t.tex); gl.deleteFramebuffer(t.fbo); } });
        blurA = makeTarget(w, h, true); blurB = makeTarget(w, h, true);
      }
      bevel = bevelPx(fontPx, scale);
      run(P.blur, blurA, { src: maskTex, step: [1 / w, 0], radius: bevel, read: 0, write: 0 });
      run(P.blur, blurB, { src: blurA.tex, step: [0, 1 / h], radius: bevel, read: 1, write: 0 });
      run(P.blur, blurA, { src: blurB.tex, step: [1 / w, 0], radius: bevel * DOME, read: 1, write: 1 });
      run(P.blur, blurB, { src: blurA.tex, step: [0, 1 / h], radius: bevel * DOME, read: 2, write: 1 });
    }
    function size() {
      var dpr = lite ? 0.65 : Math.min(window.devicePixelRatio || 1, 2);
      var w = Math.max(1, Math.round(canvas.clientWidth * dpr)), h = Math.max(1, Math.round(canvas.clientHeight * dpr));
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      var fs = lite ? 0.25 : 0.4, fw = Math.max(1, Math.round(w * fs)), fh = Math.max(1, Math.round(h * fs));
      if (!field || field.w !== fw || field.h !== fh) {
        if (field) { gl.deleteTexture(field.tex); gl.deleteFramebuffer(field.fbo); }
        field = makeTarget(fw, fh, false);
      }
      buildMask();
    }
    function draw() {
      if (!field || !blurB) return;
      var aspect = canvas.width / canvas.height;
      run(P.field, field, { time: time, aspect: aspect, octaves: lite ? 3 : 5, c0: palette[0], c1: palette[1], c2: palette[2], c3: palette[3], c4: palette[4] });
      run(P.glass, null, {
        field: field.tex, height: blurB.tex, htexel: [1 / blurB.w, 1 / blurB.h], bevel: bevel, aspect: aspect,
        light: [light.x, light.y], glass: 1,
        form: reduceMq.matches || readyAt < 0 ? 1 : formed(performance.now() - readyAt, FORM_MS),
        res: [canvas.width, canvas.height]
      });
    }
    function animating() { return inView && !document.hidden && !reduceMq.matches; }
    function frame(now) {
      raf = 0; if (disposed) return;
      var raw = (now - last) / 1000; last = now;
      var dt = Math.min(raw, 0.1);
      if (!lite && judged < 40 && animating()) {   // drop to a lighter render on slow devices
        judged++;
        if (judged > 3 && raw > SLOW_FRAME_S) slow += raw > CRAWL_FRAME_S ? 3 : 1;
        if (slow >= SLOW_FRAMES) { lite = true; size(); }
      }
      if (animating()) time += dt;
      var idle = (now - pt.at) / 1000 > IDLE_S;
      var target = idle && animating() ? orbit(time) : [pt.x, pt.y];
      light.x = follow(light.x, target[0], dt, idle ? 1.2 : 7);
      light.y = follow(light.y, target[1], dt, idle ? 1.2 : 7);
      draw();
      var catching = Math.abs(light.x - target[0]) + Math.abs(light.y - target[1]) > 0.0015;
      var forming = readyAt >= 0 && performance.now() - readyAt < FORM_MS;
      if (inView && !document.hidden && (animating() || catching || forming)) raf = requestAnimationFrame(frame);
    }
    function kick() { if (raf || disposed) return; last = performance.now(); raf = requestAnimationFrame(frame); }

    function onMove(e) {
      var r = hero.getBoundingClientRect();
      pt.x = (e.clientX - r.left) / r.width; pt.y = 1 - (e.clientY - r.top) / r.height; pt.at = performance.now(); kick();
    }
    function onLost(e) { e.preventDefault(); cancelAnimationFrame(raf); raf = 0; }
    var restart = null;
    function onRestored() { if (restart) restart(); }

    try {
      P = { field: program(FIELD), blur: program(BLUR), glass: program(GLASS) };
      gl.bindVertexArray(gl.createVertexArray());
      gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
      gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
      size();
    } catch (err) { return function () {}; }

    canvas.addEventListener("webglcontextlost", onLost);
    canvas.addEventListener("webglcontextrestored", onRestored);
    hero.addEventListener("pointermove", onMove);
    hero.dataset.glass = "true";
    readyAt = performance.now();
    kick();

    var pending = 0;
    var ro = new ResizeObserver(function () {
      cancelAnimationFrame(pending);
      pending = requestAnimationFrame(function () { if (!disposed) { size(); kick(); } });
    });
    ro.observe(hero);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { if (!disposed) { buildMask(); kick(); } });
    var io = new IntersectionObserver(function (entries) { inView = entries[0].isIntersecting; if (inView) kick(); });
    io.observe(hero);
    function onVis() { if (!document.hidden) kick(); }
    document.addEventListener("visibilitychange", onVis);
    reduceMq.addEventListener("change", kick);

    function stop() {
      disposed = true; cancelAnimationFrame(raf); cancelAnimationFrame(pending);
      ro.disconnect(); io.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      reduceMq.removeEventListener("change", kick);
      canvas.removeEventListener("webglcontextlost", onLost);
      canvas.removeEventListener("webglcontextrestored", onRestored);
      hero.removeEventListener("pointermove", onMove);
      delete hero.dataset.glass;
    }
    restart = function () { stop(); cleanup = start(); };
    return stop;
  }

  var cleanup = function () {};
  try { cleanup = start(); } catch (e) { /* keep the plain solid headline */ }
})();
