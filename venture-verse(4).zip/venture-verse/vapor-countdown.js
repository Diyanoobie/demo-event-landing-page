/* Vapor countdown: a plain-JavaScript port of the "VaporCountdown" React component.
   Every digit change is a phase change: the old digit breaks into grains that drift
   up on curl-noise wind while the new digit condenses from the same cloud.
   The real <time> element stays in the page (screen readers, and visible if the
   canvas effect is unavailable or reduced motion is on).
   Changed from the original: 8 digits (days, hours, minutes, seconds) because the
   event is more than 99 hours away, and it counts to the event start time. */
(function () {
  "use strict";

  var N = 8;                 // DD HH MM SS
  var FLOATS = 6;            // grains: x, y, vx, vy, hx, hy / vapor: x, y, vx, vy, age, life
  var MAX_GRAINS = 2500, STRIDE = 3, SPRING_K = 90, ZETA = 0.55, DRAG = 0.92, DT_MAX = 0.032;
  var FIELD_SCALE = 0.008, CURL_EPS = 0.75, PAD_X = 40, PAD_TOP = 110, PAD_BOTTOM = 20;

  var EVENT_START = new Date("2026-11-12T10:00:00+05:30").getTime();
  var EVENT_END = new Date("2026-11-12T15:00:00+05:30").getTime();

  var root = document.getElementById("vapor");
  var canvas = root && root.querySelector(".vc-canvas");
  var timeEl = root && root.querySelector("time");
  var statusEl = document.getElementById("cdStatus");
  if (!root || !canvas || !timeEl) return;
  var digitEls = Array.prototype.slice.call(root.querySelectorAll("[data-vc-digit]"));
  if (digitEls.length !== N) return;

  var reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---- small deterministic value noise ---- */
  function hash2(x, y) { var n = Math.sin(x * 127.1 + y * 311.7) * 43758.5453123; return n - Math.floor(n); }
  function vnoise(x, y) {
    var xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
    var u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
    var a = hash2(xi, yi), b = hash2(xi + 1, yi), c = hash2(xi, yi + 1), d = hash2(xi + 1, yi + 1);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  }
  function noise2(x, y) { return 0.65 * vnoise(x, y) + 0.35 * vnoise(x * 2.1 + 19.7, y * 2.1 + 7.3); }

  /* ---- clock ---- */
  var digits = "";
  var remaining = function () { return Math.max(0, EVENT_START - Date.now()); };
  var two = function (n) { return String(n).padStart(2, "0"); };
  function toDigits() {
    var rem = Math.round(remaining() / 1000);
    var d = Math.min(99, Math.floor(rem / 86400));
    var h = Math.floor((rem % 86400) / 3600);
    var m = Math.floor((rem % 3600) / 60);
    return two(d) + two(h) + two(m) + two(rem % 60);
  }
  function applyDateTime() {
    timeEl.setAttribute("datetime", "P" + Number(digits.slice(0, 2)) + "DT" + Number(digits.slice(2, 4)) + "H" + Number(digits.slice(4, 6)) + "M" + Number(digits.slice(6)) + "S");
  }
  function applyStatus() {
    if (!statusEl) return;
    var now = Date.now();
    statusEl.textContent = remaining() > 0 ? "" : now < EVENT_END ? "VentureVerse is live right now." : "VentureVerse 2026 has ended. Thank you for coming.";
  }

  /* ---- canvas / particles ---- */
  var ctx = canvas.getContext("2d");
  var grainColor = "#ffffff";
  var slots = [];
  for (var i = 0; i < N; i++) slots.push({ g: new Float32Array(MAX_GRAINS * FLOATS), v: new Float32Array(MAX_GRAINS * FLOATS), gc: 0, vc: 0, active: false });
  var glyphs = null, cells = [], cw = 0, ch = 0, lastW = 0, lastH = 0, raf = 0, last = 0, inited = false, timer = 0;
  var dampC = 2 * ZETA * Math.sqrt(SPRING_K);

  function loop(now) {
    var dt = Math.min(Math.max((now - last) / 1000, 0), DT_MAX);
    last = now;
    ctx.clearRect(0, 0, cw, ch);
    ctx.fillStyle = grainColor;
    var anyActive = false;

    for (var s = 0; s < N; s++) {
      var slot = slots[s], g = slot.g, v = slot.v, o, k;
      if (!slot.active) {                       // asleep: grains rest on their homes
        ctx.globalAlpha = 0.5;
        for (var a = 0; a < slot.gc; a++) { o = a * FLOATS; ctx.fillRect(g[o] - 1, g[o + 1] - 1, 2, 2); }
        continue;
      }
      anyActive = true;
      var settled = true;

      for (var b = 0; b < slot.gc; b++) {       // incoming grains: spring toward glyph homes
        o = b * FLOATS;
        var x = g[o], y = g[o + 1], vx = g[o + 2], vy = g[o + 3], hx = g[o + 4], hy = g[o + 5];
        vx = (vx + (SPRING_K * (hx - x) - dampC * vx) * dt) * DRAG;
        vy = (vy + (SPRING_K * (hy - y) - dampC * vy) * dt) * DRAG;
        x += vx * dt; y += vy * dt;
        g[o] = x; g[o + 1] = y; g[o + 2] = vx; g[o + 3] = vy;
        if (Math.abs(x - hx) > 0.5 || Math.abs(y - hy) > 0.5 || Math.abs(vx) > 2 || Math.abs(vy) > 2) settled = false;
        ctx.globalAlpha = 0.5 + 0.5 * Math.min(1, Math.hypot(vx, vy) / 500);
        ctx.fillRect(x - 1, y - 1, 2, 2);
      }

      var j = 0;
      while (j < slot.vc) {                     // vapor grains: curl-noise wind, drifting up
        o = j * FLOATS;
        var age = v[o + 4] + dt * 1000, life = v[o + 5];
        if (age >= life) {
          var lo = (slot.vc - 1) * FLOATS;
          for (k = 0; k < FLOATS; k++) v[o + k] = v[lo + k];
          slot.vc--;
          continue;
        }
        v[o + 4] = age;
        var px = v[o], py = v[o + 1], pvx = v[o + 2], pvy = v[o + 3];
        var nx = px * FIELD_SCALE, ny = py * FIELD_SCALE;
        var dndx = noise2(nx + CURL_EPS, ny) - noise2(nx - CURL_EPS, ny);
        var dndy = noise2(nx, ny + CURL_EPS) - noise2(nx, ny - CURL_EPS);
        var wx = dndy, wy = -dndx, cl = Math.hypot(wx, wy) || 1;
        var sp = 40 + 50 * hash2(j * 1.31, s * 7.7);
        wx = (wx / cl) * sp * 0.6;
        wy = (wy / cl) * sp * 0.6 - sp * 0.8;
        var mix = Math.min(1, dt * 5);
        pvx += (wx - pvx) * mix; pvy += (wy - pvy) * mix;
        px += pvx * dt; py += pvy * dt;
        v[o] = px; v[o + 1] = py; v[o + 2] = pvx; v[o + 3] = pvy;
        ctx.globalAlpha = (1 - age / life) * (0.5 + 0.5 * Math.min(1, Math.hypot(pvx, pvy) / 500));
        ctx.fillRect(px - 1, py - 1, 2, 2);
        j++;
      }
      if (slot.vc > 0) settled = false;

      if (settled) {                            // snap to homes and sleep
        for (var c = 0; c < slot.gc; c++) { o = c * FLOATS; g[o] = g[o + 4]; g[o + 1] = g[o + 5]; g[o + 2] = 0; g[o + 3] = 0; }
        slot.active = false;
      }
    }
    ctx.globalAlpha = 1;
    raf = anyActive ? requestAnimationFrame(loop) : 0;
  }
  function wake() { if (!raf && ctx && inited) { last = performance.now(); raf = requestAnimationFrame(loop); } }

  function transition(s, d) {
    if (!glyphs) return;
    var slot = slots[s], g = slot.g, v = slot.v, vc = 0, o, vo;
    for (var i = 0; i < slot.gc && vc < MAX_GRAINS; i++) {   // old digit becomes vapor
      o = i * FLOATS; vo = vc * FLOATS;
      v[vo] = g[o]; v[vo + 1] = g[o + 1]; v[vo + 2] = g[o + 2] * 0.4; v[vo + 3] = g[o + 3] * 0.4 - 12;
      v[vo + 4] = 0; v[vo + 5] = 600 + Math.random() * 300;
      vc++;
    }
    slot.vc = vc;
    var homes = glyphs[d], cell = cells[s], n = homes.length / 2;
    slot.gc = n;
    for (var m = 0; m < n; m++) {                            // new digit condenses from the cloud
      o = m * FLOATS;
      var hx = cell.x + homes[m * 2], hy = cell.y + homes[m * 2 + 1];
      if (vc > 0) {
        var src = ((Math.random() * vc) | 0) * FLOATS;
        g[o] = v[src] + (Math.random() - 0.5) * 10; g[o + 1] = v[src + 1] + (Math.random() - 0.5) * 10;
        g[o + 2] = (Math.random() - 0.5) * 40; g[o + 3] = -20 - Math.random() * 40;
      } else { g[o] = hx; g[o + 1] = hy; g[o + 2] = 0; g[o + 3] = 0; }
      g[o + 4] = hx; g[o + 5] = hy;
    }
    slot.active = true;
  }

  function init() {
    var rootRect = root.getBoundingClientRect();
    var w = Math.round(rootRect.width), h = Math.round(rootRect.height);
    if (w < 2 || h < 2) return;
    lastW = w; lastH = h;
    cw = w + PAD_X * 2; ch = h + PAD_TOP + PAD_BOTTOM;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = cw * dpr; canvas.height = ch * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    grainColor = getComputedStyle(digitEls[0]).color || grainColor;

    cells = digitEls.map(function (el) {
      var r = el.getBoundingClientRect();
      return { x: r.left - rootRect.left + PAD_X, y: r.top - rootRect.top + PAD_TOP };
    });

    // Rasterize glyphs 0-9 once. Every digit cell has the same fixed width (CSS), so one raster fits all.
    var cr = digitEls[0].getBoundingClientRect();
    var gw = Math.max(2, Math.ceil(cr.width)), gh = Math.max(2, Math.ceil(cr.height));
    var off = document.createElement("canvas"); off.width = gw; off.height = gh;
    var octx = off.getContext("2d", { willReadFrequently: true });
    if (!octx) return;
    var cs = getComputedStyle(digitEls[0]);
    octx.font = cs.fontWeight + " " + cs.fontSize + " " + cs.fontFamily;
    octx.textAlign = "center"; octx.textBaseline = "middle"; octx.fillStyle = "#ffffff";
    glyphs = [];
    for (var d = 0; d < 10; d++) {
      octx.clearRect(0, 0, gw, gh);
      octx.fillText(String(d), gw / 2, gh / 2);
      var alpha = octx.getImageData(0, 0, gw, gh).data, pts = [];
      for (var y = 1; y < gh; y += STRIDE) for (var x = 1; x < gw; x += STRIDE) if (alpha[(y * gw + x) * 4 + 3] > 128) pts.push(x, y);
      var total = pts.length / 2, keep = Math.max(1, Math.ceil(total / MAX_GRAINS));
      var homes = new Float32Array(Math.ceil(total / keep) * 2), n = 0;
      for (var p = 0; p < total; p += keep) { homes[n * 2] = pts[p * 2]; homes[n * 2 + 1] = pts[p * 2 + 1]; n++; }
      glyphs.push(homes.subarray(0, n * 2));
    }

    for (var s = 0; s < N; s++) {               // seat every slot on its current digit
      var slot = slots[s], hm = glyphs[Number(digits.charAt(s))], cell = cells[s], cnt = hm.length / 2;
      slot.gc = cnt; slot.vc = 0; slot.active = false;
      for (var i = 0; i < cnt; i++) {
        var o = i * FLOATS, hx = cell.x + hm[i * 2], hy = cell.y + hm[i * 2 + 1];
        slot.g[o] = hx; slot.g[o + 1] = hy; slot.g[o + 2] = 0; slot.g[o + 3] = 0; slot.g[o + 4] = hx; slot.g[o + 5] = hy;
      }
    }
    inited = true;
    root.classList.remove("vc-static");
    wake();
  }

  /* ---- tick on each second boundary ---- */
  function schedule() { timer = setTimeout(tick, 1000 - (Date.now() % 1000) + 15); }
  function tick() {
    var next = toDigits();
    if (next !== digits) {
      for (var s = 0; s < N; s++) {
        if (next.charAt(s) !== digits.charAt(s)) {
          digitEls[s].textContent = next.charAt(s);
          if (!reduced && inited) transition(s, Number(next.charAt(s)));
        }
      }
      digits = next;
      applyDateTime();
      applyStatus();
      if (!reduced) wake();
    }
    if (remaining() > 0) schedule();
  }

  digits = toDigits();
  for (var q = 0; q < N; q++) digitEls[q].textContent = digits.charAt(q);
  applyDateTime();
  applyStatus();
  if (remaining() > 0) schedule();

  if (reduced || !ctx) { root.classList.add("vc-static"); return; }   // plain digits, no canvas

  // If the effect is not ready shortly (slow font, no canvas), show the plain digits.
  setTimeout(function () { if (!inited) root.classList.add("vc-static"); }, 2500);
  var start = function () {
    init();
    if (window.ResizeObserver) {
      new ResizeObserver(function (entries) {
        var e = entries[0]; if (!e) return;
        var w = Math.round(e.contentRect.width), h = Math.round(e.contentRect.height);
        if (w !== lastW || h !== lastH) init();
      }).observe(root);
    }
  };
  // Rasterize only after the web font has loaded, so the glyph shapes are correct.
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(start); else start();
})();
