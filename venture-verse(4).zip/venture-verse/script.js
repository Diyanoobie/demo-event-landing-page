/* ===== 1. Mobile menu ===== */
const menuBtn = document.getElementById("menuBtn");
const nav = document.getElementById("nav");

function setMenu(open) {
  nav.classList.toggle("open", open);
  menuBtn.setAttribute("aria-expanded", open);
  menuBtn.textContent = open ? "Close" : "Menu";
}
menuBtn.addEventListener("click", () => setMenu(!nav.classList.contains("open")));
nav.querySelectorAll("a").forEach((link) => link.addEventListener("click", () => setMenu(false)));

/* ===== 2. Demo registration form ===== */
const form = document.getElementById("regForm");
const formMsg = document.getElementById("formMsg");

function setError(id, message) {
  document.getElementById("err-" + id).textContent = message;
  document.getElementById(id).classList.toggle("invalid", Boolean(message));
}

form.addEventListener("submit", (event) => {
  event.preventDefault(); // demo only: stop the page from reloading

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const course = document.getElementById("course").value.trim();
  const interest = document.getElementById("interest").value;
  const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  setError("name", name ? "" : "Enter your full name.");
  setError("email", emailOk ? "" : "Enter a valid email, for example name@example.com.");
  setError("course", course ? "" : "Enter your course and year.");
  setError("interest", interest ? "" : "Choose one option.");

  if (name && emailOk && course && interest) {
    formMsg.textContent = "Thanks, " + name.split(" ")[0] + ". Your demo registration is complete. Nothing was saved.";
    form.reset();
  } else {
    formMsg.textContent = "";
  }
});
